Torsion pretraining source tables
================================

These two tables are generated from the 12 full-cohort cached score files in
``source_data/torsion_pretraining/scores``. Reproduce from the repository
root with ``python code/scripts/torsion_pretraining.py analyze --scores source_data/torsion_pretraining/scores --out outputs/torsion_tables``.
Energy-extrema and target-symmetry gap changes are summarized for each
model and pretraining objective. Full-cohort and validation improvement
counts use molecule-level averages. The guide at
``docs/torsion_pretraining.rst`` defines signs, thresholds and weighting.
