# Computational cost

`summary.csv` and `trial_source_data.csv` contain SymFP runtimes and the earlier baseline measurements at given orientations or with coordinate fitting. SymFP measurements were updated on 25 September 2026; full SymFP trial records are in `jobs/`. `protocol.json` describes these records. Its single-trial search rule applies to the earlier coordinate-fitting runs, not all searches reported in the manuscript.

The manuscript's Engel grid-search and retained-energy BFGS timings are in `engel_search_summary.csv` and `engel_search_trials.csv`, with settings in `engel_search_protocol.json`. All DOTA Engel searches use three measured repetitions. Biological grid searches and BFGS searches without a CSoM-fitted start also use three repetitions; biological searches with a CSoM-fitted start use one trial. Repeated completed runs are reported as medians. A 7,200-second timeout is a censored lower bound, not a completed runtime. The earlier Engel `orientation=search` rows in `summary.csv` and `trial_source_data.csv` measure coordinate fitting alone and are not the manuscript's retained-energy search timings.

DOTA CSoM timings reported in the manuscript include orientation fitting and use the median of three repetitions after a warm-up on the seven-target set. The older DOTA CSoM `orientation=fixed` rows are given-orientation measurements and should not be substituted for those timings. All CPU measurements use one thread.

From the repository root, in the scientific environment described in the main README:

```sh
python code/scripts/benchmark_symfp.py --system ha --device cpu
python code/scripts/benchmark_symfp.py --system p97 --device cuda:0
python code/scripts/benchmark_symfp.py --system scan --device cpu
python code/scripts/benchmark_symfp.py --system dota --device cpu --targets 7
```

Use CPU and CUDA for HA, p97 and scan, and 1, 2, 4 or 7 CPU targets for DOTA. Each command runs in a fresh process, writes to `outputs/computational_cost/`, and uses the frozen inputs in `datasets/computational_cost/`. Constant model setup is excluded; graph construction, transfer, spectra and scoring are included. The scan rebuilds each regional graph. The timing runner uses a local model copy and validates floating-point operations before timing.
